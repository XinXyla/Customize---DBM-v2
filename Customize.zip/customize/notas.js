document.title = 'My new title here';/* Criado por XinXyla#0001 - Favor não apagar!
Editado por: 
*/
const configFile2 = "./config_notas.json",


nota1 = document.getElementById('n1'),
nota2 = document.getElementById('n2'),
nota3 = document.getElementById('n3'),
nota4 = document.getElementById('n4'),
nota5 = document.getElementById('n5'),
nota6 = document.getElementById('n6'),
nota7 = document.getElementById('n7'),
nota8 = document.getElementById('n8'),
nota9 = document.getElementById('n9'),
nota10 = document.getElementById('n10');

function setnotas() {
const fs = require("fs");
fs.writeFile(configFile2,JSON.stringify({"nota1": nota1.value,"nota2": nota2.value,"nota3": nota3.value,"nota4": nota4.value,"nota5": nota5.value,"nota6": nota6.value,"nota7": nota7.value,"nota8": nota8.value,"nota9": nota9.value,"nota10": nota10.value,}), (err) => { if(err) throw err; });
}


window.addEventListener("load", function() {
	const fs = require("fs");
	if(fs.existsSync(configFile2)) {
		fs.readFile(configFile2, function read(err, data) {
			if (err) throw err;
			var config = JSON.parse(data);
	
			nota1.value = config.nota1;
			nota2.value = config.nota2;
			nota3.value = config.nota3;
			nota4.value = config.nota4;
			nota5.value = config.nota5;
			nota6.value = config.nota6;
			nota7.value = config.nota7;
			nota8.value = config.nota8;
			nota9.value = config.nota9;
			nota10.value = config.nota10;
			
			});
	} else
	{	nota1.value = "1";
		nota2.value = "2";
		nota3.value = "3";
		nota4.value = "4";
		nota5.value = "5";
		nota6.value = "6";
		nota7.value = "7";
		nota8.value = "8";
		nota9.value = "9";
		nota10.value = "10";
	}
	
	});


	function abrir1() {
		document.getElementById('divn1').style.display = 'block';
		document.getElementById('divn2').style.display = 'none';
		document.getElementById('divn3').style.display = 'none';
		document.getElementById('divn4').style.display = 'none';
		document.getElementById('divn5').style.display = 'none';
		document.getElementById('divn6').style.display = 'none';
		document.getElementById('divn7').style.display = 'none';
		document.getElementById('divn8').style.display = 'none';
		document.getElementById('divn9').style.display = 'none';
		document.getElementById('divn10').style.display = 'none';
	}

	function abrir2() {
		document.getElementById('divn2').style.display = 'block';
		document.getElementById('divn1').style.display = 'none';
		document.getElementById('divn3').style.display = 'none';
		document.getElementById('divn4').style.display = 'none';
		document.getElementById('divn5').style.display = 'none';
		document.getElementById('divn6').style.display = 'none';
		document.getElementById('divn7').style.display = 'none';
		document.getElementById('divn8').style.display = 'none';
		document.getElementById('divn9').style.display = 'none';
		document.getElementById('divn10').style.display = 'none';
	}
	
	function abrir3() {
		document.getElementById('divn3').style.display = 'block';
		document.getElementById('divn1').style.display = 'none';
		document.getElementById('divn2').style.display = 'none';
		document.getElementById('divn4').style.display = 'none';
		document.getElementById('divn5').style.display = 'none';
		document.getElementById('divn6').style.display = 'none';
		document.getElementById('divn7').style.display = 'none';
		document.getElementById('divn8').style.display = 'none';
		document.getElementById('divn9').style.display = 'none';
		document.getElementById('divn10').style.display = 'none';
	}

	function abrir4() {
		document.getElementById('divn4').style.display = 'block';
		document.getElementById('divn1').style.display = 'none';
		document.getElementById('divn2').style.display = 'none';
		document.getElementById('divn3').style.display = 'none';
		document.getElementById('divn5').style.display = 'none';
		document.getElementById('divn6').style.display = 'none';
		document.getElementById('divn7').style.display = 'none';
		document.getElementById('divn8').style.display = 'none';
		document.getElementById('divn9').style.display = 'none';
		document.getElementById('divn10').style.display = 'none';
	}
	function abrir5() {
		document.getElementById('divn5').style.display = 'block';
		document.getElementById('divn1').style.display = 'none';
		document.getElementById('divn2').style.display = 'none';
		document.getElementById('divn3').style.display = 'none';
		document.getElementById('divn4').style.display = 'none';
		document.getElementById('divn6').style.display = 'none';
		document.getElementById('divn7').style.display = 'none';
		document.getElementById('divn8').style.display = 'none';
		document.getElementById('divn9').style.display = 'none';
		document.getElementById('divn10').style.display = 'none';
	}
	function abrir6() {
		document.getElementById('divn6').style.display = 'block';
		document.getElementById('divn1').style.display = 'none';
		document.getElementById('divn2').style.display = 'none';
		document.getElementById('divn3').style.display = 'none';
		document.getElementById('divn4').style.display = 'none';
		document.getElementById('divn5').style.display = 'none';
		document.getElementById('divn7').style.display = 'none';
		document.getElementById('divn8').style.display = 'none';
		document.getElementById('divn9').style.display = 'none';
		document.getElementById('divn10').style.display = 'none';
	}
	function abrir7() {
		document.getElementById('divn7').style.display = 'block';
		document.getElementById('divn1').style.display = 'none';
		document.getElementById('divn2').style.display = 'none';
		document.getElementById('divn3').style.display = 'none';
		document.getElementById('divn4').style.display = 'none';
		document.getElementById('divn5').style.display = 'none';
		document.getElementById('divn6').style.display = 'none';
		document.getElementById('divn8').style.display = 'none';
		document.getElementById('divn9').style.display = 'none';
		document.getElementById('divn10').style.display = 'none';
	}
	function abrir8() {
		document.getElementById('divn8').style.display = 'block';
		document.getElementById('divn1').style.display = 'none';
		document.getElementById('divn2').style.display = 'none';
		document.getElementById('divn3').style.display = 'none';
		document.getElementById('divn4').style.display = 'none';
		document.getElementById('divn5').style.display = 'none';
		document.getElementById('divn6').style.display = 'none';
		document.getElementById('divn7').style.display = 'none';
		document.getElementById('divn9').style.display = 'none';
		document.getElementById('divn10').style.display = 'none';
	}
	function abrir9() {
		document.getElementById('divn9').style.display = 'block';
		document.getElementById('divn1').style.display = 'none';
		document.getElementById('divn2').style.display = 'none';
		document.getElementById('divn3').style.display = 'none';
		document.getElementById('divn4').style.display = 'none';
		document.getElementById('divn5').style.display = 'none';
		document.getElementById('divn6').style.display = 'none';
		document.getElementById('divn7').style.display = 'none';
		document.getElementById('divn8').style.display = 'none';
		document.getElementById('divn10').style.display = 'none';
	}
	function abrir10() {
		document.getElementById('divn10').style.display = 'block';
		document.getElementById('divn1').style.display = 'none';
		document.getElementById('divn2').style.display = 'none';
		document.getElementById('divn3').style.display = 'none';
		document.getElementById('divn4').style.display = 'none';
		document.getElementById('divn5').style.display = 'none';
		document.getElementById('divn6').style.display = 'none';
		document.getElementById('divn7').style.display = 'none';
		document.getElementById('divn8').style.display = 'none';
		document.getElementById('divn9').style.display = 'none';
	}

	function ocultarcmd() {
		document.getElementById('cmdinfos').style.display = 'none';
		document.getElementById('cmdinfos2').style.display = 'block';
		document.getElementById('cmdinfos4').style.display = 'none';
		document.getElementById('cmdinfos3').style.height = 'calc(100% - 51px)';
	}

	function exibircmd() {
		document.getElementById('cmdinfos').style.display = 'block';
		document.getElementById('cmdinfos2').style.display = 'none';
		document.getElementById('cmdinfos4').style.display = 'block';
		document.getElementById('cmdinfos3').style.height = 'calc(100% - 204px)';
	}

	function ocultarevt() {
		document.getElementById('2cmdinfos').style.display = 'none';
		document.getElementById('2cmdinfos2').style.display = 'block';
		document.getElementById('2cmdinfos4').style.display = 'none';
		document.getElementById('2cmdinfos3').style.height = 'calc(100% - 13px)';
	}

	function exibirevt() {
		document.getElementById('2cmdinfos').style.display = 'block';
		document.getElementById('2cmdinfos2').style.display = 'none';
		document.getElementById('2cmdinfos4').style.display = 'block';
		document.getElementById('2cmdinfos3').style.height = 'calc(100% - 156px)';
	}


	function ocultarautosave() {
		document.getElementById('autoconfig1').style.display = 'none';
		document.getElementById('autoconfig2').style.display = 'block';
	}

	function exibirautosave() {
		document.getElementById('autoconfig1').style.display = 'block';
		document.getElementById('autoconfig2').style.display = 'none';
	}


	function fecharatu() {
document.getElementById('versao21').style.display = 'none';
document.querySelector("[name='txtstart']").value = "none";
document.querySelector("[name='notastxtqr']").value = "#dddddd";
document.querySelector("[name='notasbordaqr']").value = "1px solid rgb(60,60,60)";
}

function restaurar1() {

document.querySelector("[name='imagemdofundoqr']").value = "url(./bg/01.jpg) center";
}

function restaurar2() {

	document.querySelector("[name='cordofundoqr']").value = "rgba(0,0,0,0.4)";
	}

function restaurar3() {

		document.querySelector("[name='cordofundo3qr']").value = "rgba(30,30,30,0.7)";
		}

function restaurar4() {

		document.querySelector("[name='corbordacaixaxqr']").value = "1px solid rgba(60,60,60,0.7)";
		}

		function restaurar5() {

			document.querySelector("[name='savetextocaixa']").value = "#ffffff";
			}

			function restaurar6() {

				document.querySelector("[name='tamanhotxt']").value = "14px";
				}
			
function restaurar7() {

	document.querySelector("[name='savebaqr']").value = "rgba(30,30,30,0.80)";
	}

	function restaurar8() {

		document.querySelector("[name='saveactionqr']").value = "rgba(0,0,0,0.5)";
		}

				

	function setversao21(){
		document.querySelector("[name='tamanhotxt']").value = "14px";
		document.querySelector("[name='showCircle2']").value = CheckBoxElement2.checked = true
		if(CheckBoxElement2.checked) LiveCircle2.style.display = "none"
		else if (!CheckBoxElement2.checked) LiveCircle2.style.display = "";

		document.querySelector("[name='botaoespacopr']").value = "20px";
	}


	function trocar1(){document.querySelector("[name='cordofundo3qr']").type = "text";document.querySelector("[name='cordofundo3qr']").style = "width: 100%;border-radius: 4px;";}
	function trocar1h(){document.querySelector("[name='cordofundo3qr']").type = "color";document.querySelector("[name='cordofundo3qr']").style = "cursor:pointer;width: 35px;height:35px;padding:0px";}
	function trocar2(){document.querySelector("[name='saveactionqr']").type = "text";document.querySelector("[name='saveactionqr']").style = "width: 100%;border-radius: 4px;";}
	function trocar2h(){document.querySelector("[name='saveactionqr']").type = "color";document.querySelector("[name='saveactionqr']").style = "cursor:pointer;width: 35px;height:35px;padding:0px";}
	function trocar3(){document.querySelector("[name='cordofundo4qr']").type = "text";document.querySelector("[name='cordofundo4qr']").style = "width: 100%;border-radius: 4px;";}
	function trocar3h(){document.querySelector("[name='cordofundo4qr']").type = "color";document.querySelector("[name='cordofundo4qr']").style = "cursor:pointer;width: 35px;height:35px;padding:0px";}
	function trocar4(){document.querySelector("[name='savebmfundoqr']").type = "text";document.querySelector("[name='savebmfundoqr']").style = "width: 100%;border-radius: 4px;";}
	function trocar4h(){document.querySelector("[name='savebmfundoqr']").type = "color";document.querySelector("[name='savebmfundoqr']").style = "cursor:pointer;width: 35px;height:35px;padding:0px";}
	function trocar5(){document.querySelector("[name='savebaqr']").type = "text";document.querySelector("[name='savebaqr']").style = "width: 100%;border-radius: 4px;";}
	function trocar5h(){document.querySelector("[name='savebaqr']").type = "color";document.querySelector("[name='savebaqr']").style = "cursor:pointer;width: 35px;height:35px;padding:0px";}
	function trocar6(){document.querySelector("[name='savebfundoqr']").type = "text";document.querySelector("[name='savebfundoqr']").style = "width: 100%;border-radius: 4px;";}
	function trocar6h(){document.querySelector("[name='savebfundoqr']").type = "color";document.querySelector("[name='savebfundoqr']").style = "cursor:pointer;width: 35px;height:35px;padding:0px";}
	function trocar7(){document.querySelector("[name='marcadorfundo']").type = "text";document.querySelector("[name='marcadorfundo']").style = "width: 100%;border-radius: 4px;";}
	function trocar7h(){document.querySelector("[name='marcadorfundo']").type = "color";document.querySelector("[name='marcadorfundo']").style = "cursor:pointer;width: 35px;height:35px;padding:0px";}
	function trocar8(){document.querySelector("[name='rolagemfundo']").type = "text";document.querySelector("[name='rolagemfundo']").style = "width: 100%;border-radius: 4px;";}
	function trocar8h(){document.querySelector("[name='rolagemfundo']").type = "color";document.querySelector("[name='rolagemfundo']").style = "cursor:pointer;width: 35px;height:35px;padding:0px";}
	function trocar9(){document.querySelector("[name='notasfundo']").type = "text";document.querySelector("[name='notasfundo']").style = "width: 100%;border-radius: 4px;";}
	function trocar9h(){document.querySelector("[name='notasfundo']").type = "color";document.querySelector("[name='notasfundo']").style = "cursor:pointer;width: 35px;height:35px;padding:0px";}
	function trocar10(){document.querySelector("[name='acguia']").type = "text";document.querySelector("[name='acguia']").style = "width: 100%;border-radius: 4px;";}
	function trocar10h(){document.querySelector("[name='acguia']").type = "color";document.querySelector("[name='acguia']").style = "cursor:pointer;width: 35px;height:35px;padding:0px";}
	function trocar11(){document.querySelector("[name='actxtarea']").type = "text";document.querySelector("[name='actxtarea']").style = "width: 100%;border-radius: 4px;";}
	function trocar11h(){document.querySelector("[name='actxtarea']").type = "color";document.querySelector("[name='actxtarea']").style = "cursor:pointer;width: 35px;height:35px;padding:0px";}


	function checkZero(data){
		if(data.length == 1){
		  data = "0" + data;
		}
		return data;
	  }

		function saveProject() {
		DBM.saveProject();

		var today = new Date();
	var day = today.getDate() + "";
	var month = (today.getMonth() + 1) + "";
	var year = today.getFullYear() + "";
	var hour = today.getHours() + "";
	var minutes = today.getMinutes() + "";
	var seconds = today.getSeconds() + "";
	
	day = checkZero(day);
	month = checkZero(month);
	year = checkZero(year);
	hour = checkZero(hour);
	minutes = checkZero(minutes);
	seconds = checkZero(seconds);

	
		document.querySelector("[name='ultimosave']").innerText = (`Projeto salvo automaticamente em ${day}/${month}/${year} ás ${hour}:${minutes}:${seconds}`);
		document.querySelector("[name='ultimosave2']").innerText = (`Projeto salvo automaticamente em ${day}/${month}/${year} ás ${hour}:${minutes}:${seconds}`);
	  }

	  function salvarprojeto() {
		DBM.saveProject();

		var today = new Date();
	var day = today.getDate() + "";
	var month = (today.getMonth() + 1) + "";
	var year = today.getFullYear() + "";
	var hour = today.getHours() + "";
	var minutes = today.getMinutes() + "";
	var seconds = today.getSeconds() + "";
	
	day = checkZero(day);
	month = checkZero(month);
	year = checkZero(year);
	hour = checkZero(hour);
	minutes = checkZero(minutes);
	seconds = checkZero(seconds);

	
		document.querySelector("[name='ultimosave']").innerText = (`Projeto salvo em ${day}/${month}/${year} ás ${hour}:${minutes}:${seconds}`);
		document.querySelector("[name='ultimosave2']").innerText = (`Projeto salvo em ${day}/${month}/${year} ás ${hour}:${minutes}:${seconds}`);
	  }

	  function start(){
		$('.notas').bind('click', mouseHandler);
	  }

	function mouseHandler(e){
		if ($(this).hasClass('selecionado')) {
		} else {
		  $(".selecionado").removeClass('selecionado');
		  $(this).addClass('selecionado');
		} 
	  }

	  function customizeloadconfig()
	  {
		document.querySelector("[name='customizeloadconfig']").style = "display:inline-block";
	  }
	  
	
	  
	  $(document).ready(start);


	  function xinelason() {
		document.getElementById('xinelas').style.display = 'block';
		document.getElementById('xinelas').style.top = '80px';
		document.getElementById('xinelas').style.left = '20px';
	  }
	  function xinelasoff() {
		document.getElementById('xinelas').style.display = 'none';
	  }

