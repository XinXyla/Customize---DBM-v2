/* Criado por XinXyla#0001 - Favor não apagar!
Editado por: 
*/
const configFile = "./config_customize.json",

fundocustomize = document.getElementById('cordofundo'),
fundocustomize2 = document.getElementById('cordofundo2'),
customizesalvar = document.getElementById('customizesalvar'),
fundoset = document.getElementsByClassName("fundo")[0],
fundoset2 = document.getElementsByClassName("fundo2")[0],
customizesalvarset = document.getElementsByClassName("customizesalvar")[0];
window.addEventListener("load", function() {
const fs = require("fs");
if(fs.existsSync(configFile)) {
	fs.readFile(configFile, function read(err, data) {
		if (err) throw err;
		var config = JSON.parse(data);

  		fundocustomize.value = fundoset.style.background = config.fundo;
		fundocustomize2.value = fundoset2.style.background = config.fundo2;
		customizesalvar.value = customizesalvarset.style.display = config.customizesalvar;
		document.documentElement.style.setProperty("--config-fundo", document.getElementById("cordofundo").value);
		document.documentElement.style.setProperty("--config-fundo2", document.getElementById("cordofundo2").value);
		document.documentElement.style.setProperty("--config-customizesalvar", document.getElementById("customizesalvar").value);
	});
}
else {

fundocustomize.value = "url(./bg/01.jpg) center";
fundocustomize2.value = "rgba(0,0,0,0.4)";
customizesalvar.value = "0";

}

});
function setcustomize() {
const fs = require("fs");

		document.documentElement.style.setProperty("--config-fundo", document.getElementById("cordofundo").value);
		document.documentElement.style.setProperty("--config-fundo2", document.getElementById("cordofundo2").value);
		document.documentElement.style.setProperty("--config-customizesalvar", document.getElementById("customizesalvar").value);
		
fs.writeFile(configFile,JSON.stringify({"fundo": fundocustomize.value,"fundo2": fundocustomize2.value,"customizesalvar": customizesalvar.value}), (err) => { if(err) throw err; });
}