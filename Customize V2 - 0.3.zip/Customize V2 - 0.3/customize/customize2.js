/* Criado por XinXyla#0001 - Favor não apagar!
Editado por: 
*/
const configFile = "./config_customize.json",

/* Barra de rolagem */ 
rolfundo = document.getElementById('rolfundox'),
rolbarra = document.getElementById('rolbarrax'),
rolbarraativa = document.getElementById('rolbarraativax'),
rolbotoes = document.getElementById('rolbotoesx'),
rolbotoesonoff = document.getElementById('rolbotoesonoffx'),
rolborda = document.getElementById('rolbordax'),
roltamanho = document.getElementById('roltamanhox'),
rolfundoset = document.getElementsByClassName("rolfundo")[0],
rolbarraset = document.getElementsByClassName("rolbarra")[0],
rolbarraativaset = document.getElementsByClassName("rolbarraativa")[0],
rolbotoesset = document.getElementsByClassName("rolbotoes")[0],
rolbotoesonoffset = document.getElementsByClassName("rolbotoesonoff")[0],
rolbordaset = document.getElementsByClassName("rolborda")[0],
roltamanhoset = document.getElementsByClassName("roltamanho")[0],

/* Botões */
bfundo = document.getElementById('bfundox'),
btexto = document.getElementById('btextox'),
bfundohover = document.getElementById('bfundohoverx'),
btextohover = document.getElementById('btextohover'),
bfundoset = document.getElementsByClassName("bfundo")[0],
btextoset = document.getElementsByClassName("btexto")[0],
bfundohoverset = document.getElementsByClassName("bfundohover")[0],
btextohoverset = document.getElementsByClassName("btextohover")[0],

customizesalvar = document.getElementById('customizesalvar'),
customizesalvarset = document.getElementsByClassName("customizesalvar")[0],

/* Criação actions e eventos */ 
acfundo = document.getElementById('acfundo'),
actexto = document.getElementById('actexto'),
acguia = document.getElementById('acguia'),
actxtarea = document.getElementById('actxtarea'),
actxtfundo = document.getElementById('actxtfundo'),
actxtcor = document.getElementById('actxtcor'),
actxttexto = document.getElementById('actxttexto'),
acfundoset = document.getElementsByClassName("acfundo")[0],
actextoset = document.getElementsByClassName("actexto")[0],
acguiaset = document.getElementsByClassName("acguia")[0],
actxtareaset = document.getElementsByClassName("actxtarea")[0],
actxtfundoset = document.getElementsByClassName("actxtfundo")[0],
actxtcorset = document.getElementsByClassName("actxtcor")[0],
actxttextoset = document.getElementsByClassName("actxttexto")[0],

fundocustomize = document.getElementById('cordofundo'),
fundocustomize2 = document.getElementById('cordofundo2'),
fundocustomize3 = document.getElementById('cordofundo3'),
bordacaixacustomize = document.getElementById('corbordacaixax'),
textocaixacustomize = document.getElementById('cortextocaixax'),
fundoset = document.getElementsByClassName("fundo")[0],
fundoset2 = document.getElementsByClassName("fundo2")[0],
fundoset3 = document.getElementsByClassName("fundo3")[0],
bordacaixaset = document.getElementsByClassName("bordacaixa")[0],
textocaixabordaset = document.getElementsByClassName("textocaixa")[0];
window.addEventListener("load", function() {
const fs = require("fs");
if(fs.existsSync(configFile)) {
	fs.readFile(configFile, function read(err, data) {
		if (err) throw err;
		var config = JSON.parse(data);

		/* Barra de rolagem */ 
		rolfundo.value = rolfundoset.style.background = config.rolfundo;
		rolbarra.value = rolbarraset.style.background = config.rolbarra;
		rolbarraativa.value = rolbarraativaset.style.background = config.rolbarraativa;
		rolbotoes.value = rolbotoesset.style.background = config.rolbotoes;
		rolbotoesonoff.value = rolbotoesonoffset.style.background = config.rolbotoesonoff;
		rolborda.value = rolbordaset.style.background = config.rolborda;
		roltamanho.value = roltamanhoset.style.margin = config.roltamanho;
		document.documentElement.style.setProperty("--config-rolfundo", config.rolfundo);
		document.documentElement.style.setProperty("--config-rolbarra", config.rolbarra);
		document.documentElement.style.setProperty("--config-rolbarraativa", config.rolbarraativa);
		document.documentElement.style.setProperty("--config-rolbotoes", config.rolbotoes);
		document.documentElement.style.setProperty("--config-rolbotoesonoff", config.rolbotoesonoff);
		document.documentElement.style.setProperty("--config-rolborda", config.rolborda);
		document.documentElement.style.setProperty("--config-roltamanho", config.roltamanho);

		/* Botões */ 
		bfundo.value = bfundoset.style = config.bfundo;
		btexto.value = btextoset.style.background = config.btexto;
		bfundohover.value = bfundohoverset.style = config.bfundohover;
		btextohover.value = btextohoverset.style.background = config.btextohover;
		document.documentElement.style.setProperty("--config-bfundo", config.bfundo);
		document.documentElement.style.setProperty("--config-btexto", config.btexto);
		document.documentElement.style.setProperty("--config-bfundohover", config.bfundohover);
		document.documentElement.style.setProperty("--config-btextohover", config.btextohover);

		customizesalvar.value = customizesalvarset.style.display = config.customizesalvar;
		document.documentElement.style.setProperty("--config-customizesalvar", config.customizesalvar);

		fundocustomize.value = fundoset.style.background = config.fundo;
		fundocustomize2.value = fundoset2.style.background = config.fundo2;
		fundocustomize3.value = fundoset3.style.background = config.fundo3;
		bordacaixacustomize.value = bordacaixaset.style.background = config.bordacaixa;
		textocaixacustomize.value = textocaixabordaset.style.background = config.textocaixa;
		document.documentElement.style.setProperty("--config-fundo", config.fundo);
		document.documentElement.style.setProperty("--config-fundo2", config.fundo2);
		document.documentElement.style.setProperty("--config-caixafundo", config.fundo3);
		document.documentElement.style.setProperty("--config-bordacaixa", config.bordacaixa);
		document.documentElement.style.setProperty("--config-textocaixa", config.textocaixa);

		/* Criação actions e eventos */ 
		acfundo.value = acfundoset.style.background = config.acfundo;
		actexto.value = actextoset.style.background = config.actexto;
		acguia.value = acguiaset.style.background = config.acguia;

		actxtarea.value = actxtareaset.style.background = config.actxtarea;
		actxtfundo.value = actxtfundoset.style.background = config.actxtfundo;
		actxtcor.value = actxtcorset.style.background = config.actxtcor;
		actxttexto.value = actxttextoset.style.background = config.actxttexto;
		document.documentElement.style.setProperty("--config-acfundo", config.acfundo);
		document.documentElement.style.setProperty("--config-actexto", config.actexto);
		document.documentElement.style.setProperty("--config-acguia", config.acguia);

		document.documentElement.style.setProperty("--config-actxtarea", config.actxtarea);
		document.documentElement.style.setProperty("--config-actxtfundo", config.actxtfundo);
		document.documentElement.style.setProperty("--config-actxtcor", config.actxtcor);
		document.documentElement.style.setProperty("--config-actxttexto", config.actxttexto);
	});
}});