/* Criado por XinXyla#0001 - Favor não apagar!
Editado por: 
*/
const configFile = "./config_customize.json",

/* Corpo  */ 
customizetexto = document.getElementById('customizetexto'),
customizetextoset = document.getElementsByClassName("customizetexto")[0],
customizebf = document.getElementById('customizebf'),
customizebfset = document.getElementsByClassName("customizebf")[0],
customizebb = document.getElementById('customizebb'),
customizebbset = document.getElementsByClassName("customizebb")[0],
customizecxtxt = document.getElementById('customizecxtxt'),
customizecxtxtset = document.getElementsByClassName("customizecxtxt")[0],
customizecxb = document.getElementById('customizecxb'),
customizecxbset = document.getElementsByClassName("customizecxb")[0],
customizecxf = document.getElementById('customizecxf'),
customizecxfset = document.getElementsByClassName("customizecxf")[0],


/* Menu  */ 
customizemenu1 = document.getElementById('customizemenu1'),
customizemenu1set = document.getElementsByClassName("customizemenu1")[0],
customizemenu2 = document.getElementById('customizemenu2'),
customizemenu2set = document.getElementsByClassName("customizemenu2")[0],
customizemenu3 = document.getElementById('customizemenu3'),
customizemenu3set = document.getElementsByClassName("customizemenu3")[0],
customizemenu4 = document.getElementById('customizemenu4'),
customizemenu4set = document.getElementsByClassName("customizemenu4")[0],
customizemenu5 = document.getElementById('customizemenu5'),
customizemenu5set = document.getElementsByClassName("customizemenu5")[0],

/* Botões  */ 
customizebotaotexto = document.getElementById('customizebotaotexto'),
customizebotaotextoset = document.getElementsByClassName("customizebotaotexto")[0],
customizebotao = document.getElementById('customizebotao'),
customizebotaoset = document.getElementsByClassName("customizebotao")[0],

/* Marcador */ 
marcadorcustomize = document.getElementById('cordomarcador'),
marcadorcustomizetxt = document.getElementById('cordomarcadortxt'),
marcadorset = document.getElementsByClassName("marcador")[0],

/* Notas */ 
notasfundo = document.getElementById('notasfundo'),
notastxt = document.getElementById('notastxt'),
notasfundoset = document.getElementsByClassName("notasfundo")[0],
notastxtset = document.getElementsByClassName("notastxt")[0],
bordanotas = document.getElementById('bordanotas'),
bordanotasset = document.getElementsByClassName("bordanotas")[0],

fundocustomize = document.getElementById('cordofundo'),
fundocustomize2 = document.getElementById('cordofundo2'),
customizesalvar = document.getElementById('customizesalvar'),
fundoset = document.getElementsByClassName("fundo")[0],
fundoset2 = document.getElementsByClassName("fundo2")[0],
customizesalvarset = document.getElementsByClassName("customizesalvar")[0];
window.addEventListener("load", function() {
const fs = require("fs");
if(fs.existsSync(configFile)) {
	fs.readFile(configFile, function read(err, data) {
		if (err) throw err;
		var config = JSON.parse(data);

						/* Corpo */ 
						customizetexto.value = customizetextoset.style.background = config.customizetexto;
						document.documentElement.style.setProperty("--config-customizetexto", document.getElementById("customizetexto").value);
						customizebf.value = customizebfset.style.background = config.customizebf;
						document.documentElement.style.setProperty("--config-customizebf", document.getElementById("customizebf").value);
						customizebb.value = customizebbset.style.background = config.customizebb;
						document.documentElement.style.setProperty("--config-customizebb", document.getElementById("customizebb").value);
						customizecxtxt.value = customizecxtxtset.style.background = config.customizecxtxt;
						document.documentElement.style.setProperty("--config-customizecxtxt", document.getElementById("customizecxtxt").value);
						customizecxb.value = customizecxbset.style.background = config.customizecxb;
						document.documentElement.style.setProperty("--config-customizecxb", document.getElementById("customizecxb").value);
						customizecxf.value = customizecxfset.style.background = config.customizecxf;
						document.documentElement.style.setProperty("--config-customizecxf", document.getElementById("customizecxf").value);

												/* Menu */ 
												customizemenu1.value = customizemenu1set.style.background = config.customizemenu1;
												document.documentElement.style.setProperty("--config-customizemenu1", document.getElementById("customizemenu1").value);
												customizemenu2.value = customizemenu2set.style.background = config.customizemenu2;
												document.documentElement.style.setProperty("--config-customizemenu2", document.getElementById("customizemenu2").value);
												customizemenu3.value = customizemenu3set.style.background = config.customizemenu3;
												document.documentElement.style.setProperty("--config-customizemenu3", document.getElementById("customizemenu3").value);
												customizemenu4.value = customizemenu4set.style.background = config.customizemenu4;
												document.documentElement.style.setProperty("--config-customizemenu4", document.getElementById("customizemenu4").value);
												customizemenu5.value = customizemenu5set.style.background = config.customizemenu5;
												document.documentElement.style.setProperty("--config-customizemenu5", document.getElementById("customizemenu5").value);



												/* Botões */ 
												customizebotaotexto.value = customizebotaotextoset.style.background = config.customizebotaotexto;
												document.documentElement.style.setProperty("--config-customizebotaotexto", document.getElementById("customizebotaotexto").value);
												customizebotao.value = customizebotaoset.style.background = config.customizebotao;
												document.documentElement.style.setProperty("--config-customizebotao", document.getElementById("customizebotao").value);


				/* Marcador  */ 
				marcadorcustomize.value = marcadorset.style.background = config.marcador;
				marcadorcustomizetxt.value = marcadorset.style.background = config.marcadortxt;
				document.documentElement.style.setProperty("--config-marcador", document.getElementById("cordomarcador").value);
				document.documentElement.style.setProperty("--config-marcadortxt", document.getElementById("cordomarcadortxt").value);

		/* Notas */ 
		notasfundo.value = notasfundoset.style.background = config.notasfundo;
		notastxt.value = notastxtset.style.background = config.notastxt;
		bordanotas.value = bordanotasset.style.background = config.bordanotas;
		document.documentElement.style.setProperty("--config-notasfundo", document.getElementById("notasfundo").value);
		document.documentElement.style.setProperty("--config-notastxt", document.getElementById("notastxt").value);
		document.documentElement.style.setProperty("--config-bordanotas", document.getElementById("bordanotas").value);

  		fundocustomize.value = fundoset.style.background = config.fundo;
		fundocustomize2.value = fundoset2.style.background = config.fundo2;
		customizesalvar.value = customizesalvarset.style.display = config.customizesalvar;
		document.documentElement.style.setProperty("--config-fundo", document.getElementById("cordofundo").value);
		document.documentElement.style.setProperty("--config-fundo2", document.getElementById("cordofundo2").value);
		document.documentElement.style.setProperty("--config-customizesalvar", document.getElementById("customizesalvar").value);
	});
}
else {


	/* Corpo */ 
	customizetexto.value = "#ffffff";
	customizebf.value = "rgba(0,0,0,0.5)";
	customizebb.value = "0px";
	customizecxtxt.value = "#ffffff";
	customizecxb.value = "0px";
	customizecxf.value = "rgba(60,60,60,0.9)";

		/* Menu */ 
		customizemenu1.value = "#ffffff";
		customizemenu2.value = "rgba(0,0,0,0.5)";
		customizemenu3.value = "0px";
		customizemenu4.value = "#ffffff";
		customizemenu5.value = "0px";

		/* Botão */ 
		customizebotao.value = "#ffffff";
		customizebotaotexto.value = "#111";


/* Marcador */ 
marcadorcustomize.value = "#ffff00";
marcadorcustomizetxt.value = "";

/* Notas */ 
notasfundo.value = "rgba(0,0,0,0.6)";
notastxt.value = "#dddddd";
bordanotas.value = "1px solid rgba(60,60,60)";

fundocustomize.value = "url(./bg/01.jpg) center";
fundocustomize2.value = "rgba(0,0,0,0.4)";
customizesalvar.value = "0";


}

});
function setcustomize() {
const fs = require("fs");
marcadorset.style.background = marcadorcustomize.value;


		/* Corpo */ 
		document.documentElement.style.setProperty("--config-customizetexto", document.getElementById("customizetexto").value);
		document.documentElement.style.setProperty("--config-customizebf", document.getElementById("customizebf").value);
		document.documentElement.style.setProperty("--config-customizebb", document.getElementById("customizebb").value);
		document.documentElement.style.setProperty("--config-customizecxtxt", document.getElementById("customizecxtxt").value);
		document.documentElement.style.setProperty("--config-customizecxb", document.getElementById("customizecxb").value);
		document.documentElement.style.setProperty("--config-customizecxf", document.getElementById("customizecxf").value);

				/* Menu */ 
				document.documentElement.style.setProperty("--config-customizemenu1", document.getElementById("customizemenu1").value);
				document.documentElement.style.setProperty("--config-customizemenu2", document.getElementById("customizemenu2").value);
				document.documentElement.style.setProperty("--config-customizemenu3", document.getElementById("customizemenu3").value);
				document.documentElement.style.setProperty("--config-customizemenu4", document.getElementById("customizemenu4").value);
				document.documentElement.style.setProperty("--config-customizemenu5", document.getElementById("customizemenu5").value);

				/* Botão */ 
				document.documentElement.style.setProperty("--config-customizebotao", document.getElementById("customizebotao").value);
				document.documentElement.style.setProperty("--config-customizebotaotexto", document.getElementById("customizebotaotexto").value);


		/* Marcador de comandos e eventos */ 
		document.documentElement.style.setProperty("--config-marcador", document.getElementById("cordomarcador").value);
		document.documentElement.style.setProperty("--config-marcadortxt", document.getElementById("cordomarcadortxt").value);

		/* Notas */ 
		document.documentElement.style.setProperty("--config-notasfundo", document.getElementById("notasfundo").value);
		document.documentElement.style.setProperty("--config-notastxt", document.getElementById("notastxt").value);
		document.documentElement.style.setProperty("--config-bordanotas", document.getElementById("bordanotas").value);


		document.documentElement.style.setProperty("--config-fundo", document.getElementById("cordofundo").value);
		document.documentElement.style.setProperty("--config-fundo2", document.getElementById("cordofundo2").value);
		document.documentElement.style.setProperty("--config-customizesalvar", document.getElementById("customizesalvar").value);
		
		
fs.writeFile(configFile,JSON.stringify({"fundo": fundocustomize.value,"fundo2": fundocustomize2.value,"customizesalvar": customizesalvar.value,"marcador": marcadorcustomize.value,"marcadortxt": marcadorcustomizetxt.value,"notasfundo": notasfundo.value,"notastxt": notastxt.value,"bordanotas": bordanotas.value,"customizetexto": customizetexto.value,"customizebf": customizebf.value,"customizebb": customizebb.value,"customizecxtxt": customizecxtxt.value,"customizecxb": customizecxb.value,"customizecxf": customizecxf.value,"customizebotaotexto": customizebotaotexto.value,"customizebotao": customizebotao.value,"customizemenu1": customizemenu1.value,"customizemenu2": customizemenu2.value,"customizemenu3": customizemenu3.value,"customizemenu4": customizemenu4.value,"customizemenu5": customizemenu5.value}), (err) => { if(err) throw err; });
}