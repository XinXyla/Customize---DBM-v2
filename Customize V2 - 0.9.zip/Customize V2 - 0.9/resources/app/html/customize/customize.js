/* Criado por xinxyla - Favor não apagar!
Editado por: 
*/

	let versaocustomize = "0.9";

	notasgat = document.getElementById('notasgat'),
	filtrosgat = document.getElementById('filtrosgat'),
	msavegat = document.getElementById('msavegat'),
	custosavegat = document.getElementById('custosavegat'),
	bkpsave = document.getElementById('bkpsave'),

	/* Corpo  */
	customizetexto = document.getElementById('customizetexto'),
	customizebf = document.getElementById('customizebf'),
	customizebb = document.getElementById('customizebb'),
	customizecxtxt = document.getElementById('customizecxtxt'),
	customizecxb = document.getElementById('customizecxb'),
	customizecxf = document.getElementById('customizecxf'),
	customizecorpo1 = document.getElementById('customizecorpo1'),
	customizecorpo2 = document.getElementById('customizecorpo2'),
	customizec8 = document.getElementById('customizec8'),
	customizec9 = document.getElementById('customizec9'),
	customizec10 = document.getElementById('customizec10'),
	customizec11 = document.getElementById('customizec11'),
	customizec12 = document.getElementById('customizec12'),
	customizec13 = document.getElementById('customizec13'),

	/* TAB  */
	tabbg = document.getElementById('tabbg'),
	tabbghover = document.getElementById('tabbghover'),
	tabborder = document.getElementById('tabborder'),
	tabbgtop = document.getElementById('tabbgtop'),
	tabbgtopativo = document.getElementById('tabbgtopativo'),

	/* Efeito */
	efeitoinicial = document.getElementById('efeitoinicial'),
	quantidadebk = document.getElementById('quantidadebk'),

	/* Menu  */
	customizemenu1 = document.getElementById('customizemenu1'),
	customizemenu2 = document.getElementById('customizemenu2'),
	customizemenu3 = document.getElementById('customizemenu3'),
	customizemenu4 = document.getElementById('customizemenu4'),
	customizemenu5 = document.getElementById('customizemenu5'),
	customizemenu6 = document.getElementById('customizemenu6'),
	customizemenu7 = document.getElementById('customizemenu7'),

	/* Rolagem  */
	customizerolagem1 = document.getElementById('customizerolagem1'),
	customizerolagem2 = document.getElementById('customizerolagem2'),
	customizerolagem3 = document.getElementById('customizerolagem3'),
	customizerolagem4 = document.getElementById('customizerolagem4'),
	customizerolagem5 = document.getElementById('customizerolagem5'),
	customizerolagem6 = document.getElementById('customizerolagem6'),
	customizerolagem7 = document.getElementById('customizerolagem7'),

	/* Actions & Eventos  */
	customizeae1 = document.getElementById('customizeae1'),
	customizeae2 = document.getElementById('customizeae2'),
	customizeae3 = document.getElementById('customizeae3'),
	customizeae4 = document.getElementById('customizeae4'),
	customizeae5 = document.getElementById('customizeae5'),
	customizeae6 = document.getElementById('customizeae6'),
	customizeae7 = document.getElementById('customizeae7'),
	customizeae8 = document.getElementById('customizeae8'),
	customizeae9 = document.getElementById('customizeae9'),

	/* Janela de Actions  */
	customizej1 = document.getElementById('customizej1'),
	customizej2 = document.getElementById('customizej2'),
	customizej3 = document.getElementById('customizej3'),
	customizej4 = document.getElementById('customizej4'),
	customizej5 = document.getElementById('customizej5'),
	customizej6 = document.getElementById('customizej6'),
	customizej7 = document.getElementById('customizej7'),
	customizej8 = document.getElementById('customizej8'),
	customizej9 = document.getElementById('customizej9'),
	customizej10 = document.getElementById('customizej10'),
	customizej11 = document.getElementById('customizej11'),
	customizej12 = document.getElementById('customizej12'),
	customizej13 = document.getElementById('customizej13'),

	/* Botões  */
	customizebotaotexto = document.getElementById('customizebotaotexto'),
	customizebotao = document.getElementById('customizebotao'),
	customizebotaotextoh = document.getElementById('customizebotaotextoh'),
	customizebotaoh = document.getElementById('customizebotaoh'),

	/* Marcador */
	marcadorcustomize = document.getElementById('cordomarcador'),
	marcadorcustomizetxt = document.getElementById('cordomarcadortxt'),

	/* Notas */
	notasfundo = document.getElementById('notasfundo'),
	notastxt = document.getElementById('notastxt'),
	bordanotas = document.getElementById('bordanotas'),

	fundocustomize = document.getElementById('cordofundo'),
	fundocustomize2 = document.getElementById('cordofundo2'),
	customizesalvar = document.getElementById('customizesalvar');



window.addEventListener("load", function () {
	const fs = require("fs");


	fs.readFile("./config_customize.json", function read(err, data) {
		if (err) throw err;
		var configinit = JSON.parse(data);
		configFile = "./customize/config_customize_" + configinit.config_customize + ".json"



		if (fs.existsSync(configFile)) {
			fs.readFile(configFile, function read(err, data) {
				if (err) throw err;
				var config = JSON.parse(data);


				notasgat.checked = config.notasgat;
				if (notasgat.checked == true) {
					document.querySelector("[name='notasport']").style.display = "none";
				} else {
					document.querySelector("[name='notasport']").style.display = "block";
				}

				filtrosgat.checked = config.filtrosgat;
				if (filtrosgat.checked == true) {
					document.querySelector("[name='filtrosgat1']").style.display = "none";
					document.querySelector("[name='filtrosgat2']").style.display = "none";
					document.querySelector("[name='filtrosgat3']").style.display = "none";
					document.querySelector("[name='filtrosgat4']").style.display = "none";
				} else {
					document.querySelector("[name='filtrosgat1']").style.display = "block";
					document.querySelector("[name='filtrosgat2']").style.display = "block";
					document.querySelector("[name='filtrosgat3']").style.display = "block";
					document.querySelector("[name='filtrosgat4']").style.display = "block";
				}

				msavegat.checked = config.msavegat;
				if (msavegat.checked == true) {
					document.querySelector("[name='msavegat1']").style.display = "none";
					document.querySelector("[name='msavegat2']").style.display = "none";
				} else {
					document.querySelector("[name='msavegat1']").style.display = "block";
					document.querySelector("[name='msavegat2']").style.display = "block";
				}

				custosavegat.checked = config.custosavegat;
				if (custosavegat.checked == true) {
					document.querySelector("[name='custosavegat1']").style.display = "none";
				} else {
					document.querySelector("[name='custosavegat1']").style.display = "block";
				}


				bkpsave.checked = config.bkpsave;


				/* TAB */
				tabbg.value = config.tabbg !== undefined ? config.tabbg : "rgba(30,30,30,0.7)";
				document.documentElement.style.setProperty("--config-tabbg", document.getElementById("tabbg").value);
				tabbghover.value = config.tabbghover !== undefined ? config.tabbghover : "rgba(40,60,60,0.7)";
				document.documentElement.style.setProperty("--config-tabbghover", document.getElementById("tabbghover").value);
				tabborder.value = config.tabborder !== undefined ? config.tabborder : "rgba(60,60,60,0.7)";
				document.documentElement.style.setProperty("--config-tabborder", document.getElementById("tabborder").value);
				tabbgtop.value = config.tabbgtop !== undefined ? config.tabbgtop : "rgba(20,20,20,0.7)";
				document.documentElement.style.setProperty("--config-tabbgtop", document.getElementById("tabbgtop").value);
				tabbgtopativo.value = config.tabbgtopativo !== undefined ? config.tabbgtopativo : "rgba(0,0,0,0.7)";
				document.documentElement.style.setProperty("--config-tabbgtopativo", document.getElementById("tabbgtopativo").value);

				/* Efeito */
				efeitoinicial.value = config.efeitoinicial !== undefined ? config.efeitoinicial : "jiggle";
				document.documentElement.style.setProperty("--config-efeitoinicial", document.getElementById("efeitoinicial").value);

				quantidadebk.value = config.quantidadebk !== undefined ? config.quantidadebk : "10";
				document.documentElement.style.setProperty("--config-quantidadebk", document.getElementById("quantidadebk").value);

				/* Corpo */
				customizetexto.value = config.customizetexto;
				document.documentElement.style.setProperty("--config-customizetexto", document.getElementById("customizetexto").value);
				customizebf.value = config.customizebf;
				document.documentElement.style.setProperty("--config-customizebf", document.getElementById("customizebf").value);
				customizebb.value = config.customizebb;
				document.documentElement.style.setProperty("--config-customizebb", document.getElementById("customizebb").value);
				customizecxtxt.value = config.customizecxtxt;
				document.documentElement.style.setProperty("--config-customizecxtxt", document.getElementById("customizecxtxt").value);
				customizecxb.value = config.customizecxb;
				document.documentElement.style.setProperty("--config-customizecxb", document.getElementById("customizecxb").value);
				customizecxf.value = config.customizecxf;
				document.documentElement.style.setProperty("--config-customizecxf", document.getElementById("customizecxf").value);
				customizecorpo1.value = config.customizecorpo1;
				document.documentElement.style.setProperty("--config-customizecorpo1", document.getElementById("customizecorpo1").value);
				customizecorpo2.value = config.customizecorpo2;
				document.documentElement.style.setProperty("--config-customizecorpo2", document.getElementById("customizecorpo2").value);
				customizec8.value = config.customizec8 !== "undefined" ? config.customizec8 : "#000000";
				document.documentElement.style.setProperty("--config-customizec8", document.getElementById("customizec8").value);
				customizec9.value = config.customizec9 !== "undefined" ? config.customizec9 : "#222222";
				document.documentElement.style.setProperty("--config-customizec9", document.getElementById("customizec9").value);
				customizec10.value = config.customizec10 !== "undefined" ? config.customizec10 : "#cccccc";
				document.documentElement.style.setProperty("--config-customizec10", document.getElementById("customizec10").value);
				customizec11.value = config.customizec11 !== "undefined" ? config.customizec11 : "#00ff00";
				document.documentElement.style.setProperty("--config-customizec11", document.getElementById("customizec11").value);
				customizec12.value = config.customizec12 !== "undefined" ? config.customizec12 : "0px";
				document.documentElement.style.setProperty("--config-customizec12", document.getElementById("customizec12").value);
				customizec13.value = config.customizec13 !== "undefined" ? config.customizec13 : "0px";
				document.documentElement.style.setProperty("--config-customizec13", document.getElementById("customizec13").value);

				/* Menu */
				customizemenu1.value = config.customizemenu1;
				document.documentElement.style.setProperty("--config-customizemenu1", document.getElementById("customizemenu1").value);
				customizemenu2.value = config.customizemenu2;
				document.documentElement.style.setProperty("--config-customizemenu2", document.getElementById("customizemenu2").value);
				customizemenu3.value = config.customizemenu3;
				document.documentElement.style.setProperty("--config-customizemenu3", document.getElementById("customizemenu3").value);
				customizemenu4.value = config.customizemenu4;
				document.documentElement.style.setProperty("--config-customizemenu4", document.getElementById("customizemenu4").value);
				customizemenu5.value = config.customizemenu5;
				document.documentElement.style.setProperty("--config-customizemenu5", document.getElementById("customizemenu5").value);
				customizemenu6.value = config.customizemenu6;
				document.documentElement.style.setProperty("--config-customizemenu6", document.getElementById("customizemenu6").value);
				customizemenu7.value = config.customizemenu7;
				document.documentElement.style.setProperty("--config-customizemenu7", document.getElementById("customizemenu7").value);

				/* Rolagem */
				customizerolagem1.value = config.customizerolagem1;
				document.documentElement.style.setProperty("--config-customizerolagem1", document.getElementById("customizerolagem1").value);
				customizerolagem2.value = config.customizerolagem2;
				document.documentElement.style.setProperty("--config-customizerolagem2", document.getElementById("customizerolagem2").value);
				customizerolagem3.value = config.customizerolagem3;
				document.documentElement.style.setProperty("--config-customizerolagem3", document.getElementById("customizerolagem3").value);
				customizerolagem4.value = config.customizerolagem4;
				document.documentElement.style.setProperty("--config-customizerolagem4", document.getElementById("customizerolagem4").value);
				customizerolagem5.value = config.customizerolagem5;
				document.documentElement.style.setProperty("--config-customizerolagem5", document.getElementById("customizerolagem5").value);
				customizerolagem6.value = config.customizerolagem6;
				document.documentElement.style.setProperty("--config-customizerolagem6", document.getElementById("customizerolagem6").value);
				customizerolagem7.value = config.customizerolagem7;
				document.documentElement.style.setProperty("--config-customizerolagem7", document.getElementById("customizerolagem7").value);

				/* Actions & Eventos  */
				customizeae1.value = config.customizeae1;
				document.documentElement.style.setProperty("--config-customizeae1", document.getElementById("customizeae1").value);
				customizeae2.value = config.customizeae2;
				document.documentElement.style.setProperty("--config-customizeae2", document.getElementById("customizeae2").value);
				customizeae3.value = config.customizeae3;
				document.documentElement.style.setProperty("--config-customizeae3", document.getElementById("customizeae3").value);
				customizeae4.value = config.customizeae4;
				document.documentElement.style.setProperty("--config-customizeae4", document.getElementById("customizeae4").value);
				customizeae5.value = config.customizeae5;
				document.documentElement.style.setProperty("--config-customizeae5", document.getElementById("customizeae5").value);
				customizeae6.value = config.customizeae6;
				document.documentElement.style.setProperty("--config-customizeae6", document.getElementById("customizeae6").value);
				customizeae7.value = config.customizeae7 !== "undefined" ? config.customizeae7 : "#000000";
				document.documentElement.style.setProperty("--config-customizeae7", document.getElementById("customizeae7").value);
				customizeae8.value = config.customizeae8 !== "undefined" ? config.customizeae8 : "1px solid #666666";
				document.documentElement.style.setProperty("--config-customizeae8", document.getElementById("customizeae8").value);
				customizeae9.value = config.customizeae9 !== "undefined" ? config.customizeae9 : "#cccccc";
				document.documentElement.style.setProperty("--config-customizeae9", document.getElementById("customizeae9").value);


				/* Janela de Actions  */
				customizej1.value = config.customizej1;
				document.documentElement.style.setProperty("--config-customizej1", document.getElementById("customizej1").value);
				customizej2.value = config.customizej2;
				document.documentElement.style.setProperty("--config-customizej2", document.getElementById("customizej2").value);
				customizej3.value = config.customizej3;
				document.documentElement.style.setProperty("--config-customizej3", document.getElementById("customizej3").value);
				customizej4.value = config.customizej4;
				document.documentElement.style.setProperty("--config-customizej4", document.getElementById("customizej4").value);
				customizej5.value = config.customizej5;
				document.documentElement.style.setProperty("--config-customizej5", document.getElementById("customizej5").value);
				customizej6.value = config.customizej6;
				document.documentElement.style.setProperty("--config-customizej6", document.getElementById("customizej6").value);
				customizej7.value = config.customizej7;
				document.documentElement.style.setProperty("--config-customizej7", document.getElementById("customizej7").value);
				customizej8.value = config.customizej8 !== "undefined" ? config.customizej8 : "#222222";
				document.documentElement.style.setProperty("--config-customizej8", document.getElementById("customizej8").value);
				customizej9.value = config.customizej9 !== "undefined" ? config.customizej9 : "#000000";
				document.documentElement.style.setProperty("--config-customizej9", document.getElementById("customizej9").value);
				customizej10.value = config.customizej10 !== "undefined" ? config.customizej10 : "#ffffff";
				document.documentElement.style.setProperty("--config-customizej10", document.getElementById("customizej10").value);
				customizej11.value = config.customizej11 !== "undefined" ? config.customizej11 : "#0edd37";
				document.documentElement.style.setProperty("--config-customizej11", document.getElementById("customizej11").value);
				customizej12.value = config.customizej12 !== "undefined" ? config.customizej12 : "1px solid #555555";
				document.documentElement.style.setProperty("--config-customizej12", document.getElementById("customizej12").value);
				customizej13.value = config.customizej13 !== "undefined" ? config.customizej13 : "1px solid #555555";
				document.documentElement.style.setProperty("--config-customizej13", document.getElementById("customizej13").value);

				/* Botões */
				customizebotaotexto.value = config.customizebotaotexto;
				document.documentElement.style.setProperty("--config-customizebotaotexto", document.getElementById("customizebotaotexto").value);
				customizebotao.value = config.customizebotao;
				document.documentElement.style.setProperty("--config-customizebotao", document.getElementById("customizebotao").value);
				customizebotaotextoh.value = config.customizebotaotextoh;
				document.documentElement.style.setProperty("--config-customizebotaotextoh", document.getElementById("customizebotaotextoh").value);
				customizebotaoh.value = config.customizebotaoh;
				document.documentElement.style.setProperty("--config-customizebotaoh", document.getElementById("customizebotaoh").value);


				/* Marcador  */
				marcadorcustomize.value = config.marcador;
				marcadorcustomizetxt.value = config.marcadortxt;
				document.documentElement.style.setProperty("--config-marcador", document.getElementById("cordomarcador").value);
				document.documentElement.style.setProperty("--config-marcadortxt", document.getElementById("cordomarcadortxt").value);

				/* Notas */
				notasfundo.value = config.notasfundo;
				notastxt.value = config.notastxt;
				bordanotas.value = config.bordanotas;
				document.documentElement.style.setProperty("--config-notasfundo", document.getElementById("notasfundo").value);
				document.documentElement.style.setProperty("--config-notastxt", document.getElementById("notastxt").value);
				document.documentElement.style.setProperty("--config-bordanotas", document.getElementById("bordanotas").value);

				fundocustomize.value = config.fundo;
				fundocustomize2.value = config.fundo2;
				customizesalvar.value = config.customizesalvar;
				document.documentElement.style.setProperty("--config-fundo", document.getElementById("cordofundo").value);
				document.documentElement.style.setProperty("--config-fundo2", document.getElementById("cordofundo2").value);
				document.documentElement.style.setProperty("--config-customizesalvar", document.getElementById("customizesalvar").value);

				if (config.versaocustomize !== "0.9") {
					versaocustomize = "0.9"

					customizec8.value = "#000000";
					document.documentElement.style.setProperty("--config-customizec8", document.getElementById("customizec8").value);
					customizec9.value = "#222222";
					document.documentElement.style.setProperty("--config-customizec9", document.getElementById("customizec9").value);
					customizec10.value = "#cccccc";
					document.documentElement.style.setProperty("--config-customizec10", document.getElementById("customizec10").value);
					customizec11.value = "#00ff00";
					document.documentElement.style.setProperty("--config-customizec11", document.getElementById("customizec11").value);
					customizec12.value = "0px";
					document.documentElement.style.setProperty("--config-customizec12", document.getElementById("customizec12").value);
					customizec13.value = "0px";
					document.documentElement.style.setProperty("--config-customizec13", document.getElementById("customizec13").value);

					customizeae7.value = "#000000"
					document.documentElement.style.setProperty("--config-customizeae7", document.getElementById("customizeae7").value)
					customizeae8.value = "1px solid #666666"
					document.documentElement.style.setProperty("--config-customizeae8", document.getElementById("customizeae8").value)
					customizeae9.value = "#cccccc"
					document.documentElement.style.setProperty("--config-customizeae9", document.getElementById("customizeae9").value)
					customizej8.value = "#222222";
					document.documentElement.style.setProperty("--config-customizej8", document.getElementById("customizej8").value);
					customizej9.value = "#000000";
					document.documentElement.style.setProperty("--config-customizej9", document.getElementById("customizej9").value);
					customizej10.value = "#ffffff";
					document.documentElement.style.setProperty("--config-customizej10", document.getElementById("customizej10").value);
					customizej11.value = "#0edd37";
					document.documentElement.style.setProperty("--config-customizej11", document.getElementById("customizej11").value);
					customizej12.value = "1px solid #555555";
					document.documentElement.style.setProperty("--config-customizej12", document.getElementById("customizej12").value);
					customizej13.value = "1px solid #555555";
					document.documentElement.style.setProperty("--config-customizej13", document.getElementById("customizej13").value);
					setcustomize()
				}


			});
		}
		else {

			setcustomizepadrao()
			setcustomize()

		}

	})

});


function customizereload() {
	const fs = require("fs");

	fs.readFile("./config_customize.json", function read(err, data) {
		if (err) throw err;
		var configinit = JSON.parse(data);
		configFile = "./customize/config_customize_" + configinit.config_customize + ".json"

		if (fs.existsSync(configFile)) {
			fs.readFile(configFile, function read(err, data) {
				if (err) throw err;
				var config = JSON.parse(data);

				notasgat.checked = config.notasgat;
				if (notasgat.checked == true) {
					document.querySelector("[name='notasport']").style.display = "none";
				} else {
					document.querySelector("[name='notasport']").style.display = "block";
				}

				filtrosgat.checked = config.filtrosgat;
				if (filtrosgat.checked == true) {
					document.querySelector("[name='filtrosgat1']").style.display = "none";
					document.querySelector("[name='filtrosgat2']").style.display = "none";
					document.querySelector("[name='filtrosgat3']").style.display = "none";
					document.querySelector("[name='filtrosgat4']").style.display = "none";
				} else {
					document.querySelector("[name='filtrosgat1']").style.display = "block";
					document.querySelector("[name='filtrosgat2']").style.display = "block";
					document.querySelector("[name='filtrosgat3']").style.display = "block";
					document.querySelector("[name='filtrosgat4']").style.display = "block";
				}


				msavegat.checked = config.msavegat;
				if (msavegat.checked == true) {
					document.querySelector("[name='msavegat1']").style.display = "none";
					document.querySelector("[name='msavegat2']").style.display = "none";
				} else {
					document.querySelector("[name='msavegat1']").style.display = "block";
					document.querySelector("[name='msavegat2']").style.display = "block";
				}

				custosavegat.checked = config.custosavegat;
				if (custosavegat.checked == true) {
					document.querySelector("[name='custosavegat1']").style.display = "none";
				} else {
					document.querySelector("[name='custosavegat1']").style.display = "block";
				}

				bkpsave.checked = config.bkpsave;


				/* TAB */
				tabbg.value = config.tabbg !== undefined ? config.tabbg : "rgba(30,30,30,0.7)";
				document.documentElement.style.setProperty("--config-tabbg", document.getElementById("tabbg").value);
				tabbghover.value = config.tabbghover !== undefined ? config.tabbghover : "rgba(40,60,60,0.7)";
				document.documentElement.style.setProperty("--config-tabbghover", document.getElementById("tabbghover").value);
				tabborder.value = config.tabborder !== undefined ? config.tabborder : "rgba(60,60,60,0.7)";
				document.documentElement.style.setProperty("--config-tabborder", document.getElementById("tabborder").value);
				tabbgtop.value = config.tabbgtop !== undefined ? config.tabbgtop : "rgba(20,20,20,0.7)";
				document.documentElement.style.setProperty("--config-tabbgtop", document.getElementById("tabbgtop").value);
				tabbgtopativo.value = config.tabbgtopativo !== undefined ? config.tabbgtopativo : "rgba(0,0,0,0.7)";
				document.documentElement.style.setProperty("--config-tabbgtopativo", document.getElementById("tabbgtopativo").value);

				/* Efeito */
				efeitoinicial.value = config.efeitoinicial !== undefined ? config.efeitoinicial : "jiggle";
				document.documentElement.style.setProperty("--config-efeitoinicial", document.getElementById("efeitoinicial").value);

				quantidadebk.value = config.quantidadebk !== undefined ? config.quantidadebk : "10";
				document.documentElement.style.setProperty("--config-quantidadebk", document.getElementById("quantidadebk").value);

				/* Corpo */
				customizetexto.value = config.customizetexto;
				document.documentElement.style.setProperty("--config-customizetexto", document.getElementById("customizetexto").value);
				customizebf.value = config.customizebf;
				document.documentElement.style.setProperty("--config-customizebf", document.getElementById("customizebf").value);
				customizebb.value = config.customizebb;
				document.documentElement.style.setProperty("--config-customizebb", document.getElementById("customizebb").value);
				customizecxtxt.value = config.customizecxtxt;
				document.documentElement.style.setProperty("--config-customizecxtxt", document.getElementById("customizecxtxt").value);
				customizecxb.value = config.customizecxb;
				document.documentElement.style.setProperty("--config-customizecxb", document.getElementById("customizecxb").value);
				customizecxf.value = config.customizecxf;
				document.documentElement.style.setProperty("--config-customizecxf", document.getElementById("customizecxf").value);
				customizecorpo1.value = config.customizecorpo1;
				document.documentElement.style.setProperty("--config-customizecorpo1", document.getElementById("customizecorpo1").value);
				customizecorpo2.value = config.customizecorpo2;
				document.documentElement.style.setProperty("--config-customizecorpo2", document.getElementById("customizecorpo2").value);
				customizec8.value = config.customizec8 !== "undefined" ? config.customizec8 : "#000000";
				document.documentElement.style.setProperty("--config-customizec8", document.getElementById("customizec8").value);
				customizec9.value = config.customizec9 !== "undefined" ? config.customizec9 : "#222222";
				document.documentElement.style.setProperty("--config-customizec9", document.getElementById("customizec9").value);
				customizec10.value = config.customizec10 !== "undefined" ? config.customizec10 : "#cccccc";
				document.documentElement.style.setProperty("--config-customizec10", document.getElementById("customizec10").value);
				customizec11.value = config.customizec11 !== "undefined" ? config.customizec11 : "#00ff00";
				document.documentElement.style.setProperty("--config-customizec11", document.getElementById("customizec11").value);
				customizec12.value = config.customizec12 !== "undefined" ? config.customizec12 : "0px";
				document.documentElement.style.setProperty("--config-customizec12", document.getElementById("customizec12").value);
				customizec13.value = config.customizec13 !== "undefined" ? config.customizec13 : "0px";
				document.documentElement.style.setProperty("--config-customizec13", document.getElementById("customizec13").value);

				/* Menu */
				customizemenu1.value = config.customizemenu1;
				document.documentElement.style.setProperty("--config-customizemenu1", document.getElementById("customizemenu1").value);
				customizemenu2.value = config.customizemenu2;
				document.documentElement.style.setProperty("--config-customizemenu2", document.getElementById("customizemenu2").value);
				customizemenu3.value = config.customizemenu3;
				document.documentElement.style.setProperty("--config-customizemenu3", document.getElementById("customizemenu3").value);
				customizemenu4.value = config.customizemenu4;
				document.documentElement.style.setProperty("--config-customizemenu4", document.getElementById("customizemenu4").value);
				customizemenu5.value = config.customizemenu5;
				document.documentElement.style.setProperty("--config-customizemenu5", document.getElementById("customizemenu5").value);
				customizemenu6.value = config.customizemenu6;
				document.documentElement.style.setProperty("--config-customizemenu6", document.getElementById("customizemenu6").value);
				customizemenu7.value = config.customizemenu7;
				document.documentElement.style.setProperty("--config-customizemenu7", document.getElementById("customizemenu7").value);

				/* Rolagem */
				customizerolagem1.value = config.customizerolagem1;
				document.documentElement.style.setProperty("--config-customizerolagem1", document.getElementById("customizerolagem1").value);
				customizerolagem2.value = config.customizerolagem2;
				document.documentElement.style.setProperty("--config-customizerolagem2", document.getElementById("customizerolagem2").value);
				customizerolagem3.value = config.customizerolagem3;
				document.documentElement.style.setProperty("--config-customizerolagem3", document.getElementById("customizerolagem3").value);
				customizerolagem4.value = config.customizerolagem4;
				document.documentElement.style.setProperty("--config-customizerolagem4", document.getElementById("customizerolagem4").value);
				customizerolagem5.value = config.customizerolagem5;
				document.documentElement.style.setProperty("--config-customizerolagem5", document.getElementById("customizerolagem5").value);
				customizerolagem6.value = config.customizerolagem6;
				document.documentElement.style.setProperty("--config-customizerolagem6", document.getElementById("customizerolagem6").value);
				customizerolagem7.value = config.customizerolagem7;
				document.documentElement.style.setProperty("--config-customizerolagem7", document.getElementById("customizerolagem7").value);

				/* Actions & Eventos  */
				customizeae1.value = config.customizeae1;
				document.documentElement.style.setProperty("--config-customizeae1", document.getElementById("customizeae1").value);
				customizeae2.value = config.customizeae2;
				document.documentElement.style.setProperty("--config-customizeae2", document.getElementById("customizeae2").value);
				customizeae3.value = config.customizeae3;
				document.documentElement.style.setProperty("--config-customizeae3", document.getElementById("customizeae3").value);
				customizeae4.value = config.customizeae4;
				document.documentElement.style.setProperty("--config-customizeae4", document.getElementById("customizeae4").value);
				customizeae5.value = config.customizeae5;
				document.documentElement.style.setProperty("--config-customizeae5", document.getElementById("customizeae5").value);
				customizeae6.value = config.customizeae6;
				document.documentElement.style.setProperty("--config-customizeae6", document.getElementById("customizeae6").value);
				customizeae7.value = config.customizeae7 !== "undefined" ? config.customizeae7 : "#000000";
				document.documentElement.style.setProperty("--config-customizeae7", document.getElementById("customizeae7").value);
				customizeae8.value = config.customizeae8 !== "undefined" ? config.customizeae8 : "1px solid #666666";
				document.documentElement.style.setProperty("--config-customizeae8", document.getElementById("customizeae8").value);
				customizeae9.value = config.customizeae9 !== "undefined" ? config.customizeae9 : "#cccccc";
				document.documentElement.style.setProperty("--config-customizeae9", document.getElementById("customizeae9").value);


				/* Janela de Actions  */
				customizej1.value = config.customizej1;
				document.documentElement.style.setProperty("--config-customizej1", document.getElementById("customizej1").value);
				customizej2.value = config.customizej2;
				document.documentElement.style.setProperty("--config-customizej2", document.getElementById("customizej2").value);
				customizej3.value = config.customizej3;
				document.documentElement.style.setProperty("--config-customizej3", document.getElementById("customizej3").value);
				customizej4.value = config.customizej4;
				document.documentElement.style.setProperty("--config-customizej4", document.getElementById("customizej4").value);
				customizej5.value = config.customizej5;
				document.documentElement.style.setProperty("--config-customizej5", document.getElementById("customizej5").value);
				customizej6.value = config.customizej6;
				document.documentElement.style.setProperty("--config-customizej6", document.getElementById("customizej6").value);
				customizej7.value = config.customizej7;
				document.documentElement.style.setProperty("--config-customizej7", document.getElementById("customizej7").value);
				customizej8.value = config.customizej8 !== "undefined" ? config.customizej8 : "#222222";
				document.documentElement.style.setProperty("--config-customizej8", document.getElementById("customizej8").value);
				customizej9.value = config.customizej9 !== "undefined" ? config.customizej9 : "#000000";
				document.documentElement.style.setProperty("--config-customizej9", document.getElementById("customizej9").value);
				customizej10.value = config.customizej10 !== "undefined" ? config.customizej10 : "#ffffff";
				document.documentElement.style.setProperty("--config-customizej10", document.getElementById("customizej10").value);
				customizej11.value = config.customizej11 !== "undefined" ? config.customizej11 : "#0edd37";
				document.documentElement.style.setProperty("--config-customizej11", document.getElementById("customizej11").value);
				customizej12.value = config.customizej12 !== "undefined" ? config.customizej12 : "1px solid #555555";
				document.documentElement.style.setProperty("--config-customizej12", document.getElementById("customizej12").value);
				customizej13.value = config.customizej13 !== "undefined" ? config.customizej13 : "1px solid #555555";
				document.documentElement.style.setProperty("--config-customizej13", document.getElementById("customizej13").value);

				/* Botões */
				customizebotaotexto.value = config.customizebotaotexto;
				document.documentElement.style.setProperty("--config-customizebotaotexto", document.getElementById("customizebotaotexto").value);
				customizebotao.value = config.customizebotao;
				document.documentElement.style.setProperty("--config-customizebotao", document.getElementById("customizebotao").value);
				customizebotaotextoh.value = config.customizebotaotextoh;
				document.documentElement.style.setProperty("--config-customizebotaotextoh", document.getElementById("customizebotaotextoh").value);
				customizebotaoh.value = config.customizebotaoh;
				document.documentElement.style.setProperty("--config-customizebotaoh", document.getElementById("customizebotaoh").value);


				/* Marcador  */
				marcadorcustomize.value = config.marcador;
				marcadorcustomizetxt.value = config.marcadortxt;
				document.documentElement.style.setProperty("--config-marcador", document.getElementById("cordomarcador").value);
				document.documentElement.style.setProperty("--config-marcadortxt", document.getElementById("cordomarcadortxt").value);

				/* Notas */
				notasfundo.value = config.notasfundo;
				notastxt.value = config.notastxt;
				bordanotas.value = config.bordanotas;
				document.documentElement.style.setProperty("--config-notasfundo", document.getElementById("notasfundo").value);
				document.documentElement.style.setProperty("--config-notastxt", document.getElementById("notastxt").value);
				document.documentElement.style.setProperty("--config-bordanotas", document.getElementById("bordanotas").value);

				fundocustomize.value = config.fundo;
				fundocustomize2.value = config.fundo2;
				customizesalvar.value = config.customizesalvar;
				document.documentElement.style.setProperty("--config-fundo", document.getElementById("cordofundo").value);
				document.documentElement.style.setProperty("--config-fundo2", document.getElementById("cordofundo2").value);
				document.documentElement.style.setProperty("--config-customizesalvar", document.getElementById("customizesalvar").value);

				/* REPARADOR CASO REMOVA*/

				reparadorcustomize()
				setcustomize()
			});
		}
		else {

			setcustomizepadrao()
			setcustomize()

		}
	})
}

function reparadorcustomize() {
	if (customizeae7.value == "undefineds") {
		customizeae7.value = "#000000"
		document.documentElement.style.setProperty("--config-customizeae7", document.getElementById("customizeae7").value)
	}
}

function setcustomizepadrao() {

	notasgat.checked = false;

	if (notasgat.checked == true) {
		document.querySelector("[name='notasport']").style.display = "none";
	} else {
		document.querySelector("[name='notasport']").style.display = "block";
	}

	filtrosgat.checked = false;
	if (filtrosgat.checked == true) {
		document.querySelector("[name='filtrosgat1']").style.display = "none";
		document.querySelector("[name='filtrosgat2']").style.display = "none";
		document.querySelector("[name='filtrosgat3']").style.display = "none";
		document.querySelector("[name='filtrosgat4']").style.display = "none";
	} else {
		document.querySelector("[name='filtrosgat1']").style.display = "block";
		document.querySelector("[name='filtrosgat2']").style.display = "block";
		document.querySelector("[name='filtrosgat3']").style.display = "block";
		document.querySelector("[name='filtrosgat4']").style.display = "block";
	}

	custosavegat.checked = false;
	if (custosavegat.checked == true) {
		document.querySelector("[name='custosavegat1']").style.display = "none";
	} else {
		document.querySelector("[name='custosavegat1']").style.display = "block";
	}


	msavegat.checked = false;
	if (msavegat.checked == true) {
		document.querySelector("[name='msavegat1']").style.display = "none";
		document.querySelector("[name='msavegat2']").style.display = "none";
	} else {
		document.querySelector("[name='msavegat1']").style.display = "block";
		document.querySelector("[name='msavegat2']").style.display = "block";
	}

	bkpsave.checked = false;


	/* TAB */
	tabbg.value = "rgba(30,30,30,0.7)";
	tabbghover.value = "rgba(40,60,60,0.7)";
	tabborder.value = "rgba(60,60,60,0.7)";
	tabbgtop.value = "rgba(20,20,20,0.7)";
	tabbgtopativo.value = "rgba(0,0,0,0.7)";

	/* Efeito */
	efeitoinicial.value = "jiggle";

	quantidadebk.value = "10";

	/* Corpo */
	customizetexto.value = "#ffffff";
	customizebf.value = "rgba(0,0,0,0.5)";
	customizebb.value = "0px";
	customizecxtxt.value = "#ffffff";
	customizecxb.value = "0px";
	customizecxf.value = "rgba(60,60,60,0.9)";
	customizecorpo1.value = "rgba(0,0,0,0.5)";
	customizecorpo2.value = "0px";
	customizec8.value = "#000000";
	customizec9.value = "#222222";
	customizec10.value = "#cccccc";
	customizec11.value = "#00ff00";
	customizec12.value = "0px";
	customizec13.value = "0px";

	/* Menu */
	customizemenu1.value = "rgba(40,40,40,0.5)";
	customizemenu2.value = "1px solid rgba(250,250,250,0.5)";
	customizemenu3.value = "#ffffff";
	customizemenu4.value = "#000000";
	customizemenu5.value = "#ffffff";
	customizemenu6.value = "0px 1px";
	customizemenu7.value = "5px";


	/* Rolagem */
	customizerolagem1.value = "rgb(0,0,0)";
	customizerolagem2.value = "1px solid #222";
	customizerolagem3.value = "rgb(100,150,200)";
	customizerolagem4.value = "rgb(200,200,200)";
	customizerolagem5.value = "none";
	customizerolagem6.value = "rgb(100,150,200)";
	customizerolagem7.value = "10px";


	/* Actions & Eventos  */
	customizeae1.value = "#222222";
	customizeae2.value = "#dddddd";
	customizeae3.value = "#000000";
	customizeae4.value = "#ffffff";
	customizeae5.value = "1px solid #333333";
	customizeae6.value = "1px solid rgb(150,150,200)";
	customizeae7.value = "#000000";
	customizeae8.value = "1px solid #666666";
	customizeae9.value = "#cccccc";


	/* Janela de Actions  */
	customizej1.value = "#111111";
	customizej2.value = "#C8C8C8";
	customizej3.value = "#222222";
	customizej4.value = "#222222";
	customizej5.value = "#C8C8C8";
	customizej6.value = "1px solid #555";
	customizej7.value = "url(./bg/01.gif) center";
	customizej8.value = "#222222";
	customizej9.value = "#000000";
	customizej10.value = "#ffffff";
	customizej11.value = "#0edd37";
	customizej12.value = "1px solid #555555";
	customizej13.value = "1px solid #555555";

	/* Botão */
	customizebotao.value = "rgba(200,250,250,0.5)";
	customizebotaotexto.value = "#111111";
	customizebotaoh.value = "rgba(200,250,250,0.7)";
	customizebotaotextoh.value = "#000000";

	/* Marcador */
	marcadorcustomize.value = "#ffff00";
	marcadorcustomizetxt.value = "";

	/* Notas */
	notasfundo.value = "rgba(0,0,0,0.6)";
	notastxt.value = "#dddddd";
	bordanotas.value = "1px solid rgba(60,60,60)";

	fundocustomize.value = "url(./bg/01.jpg) center";
	fundocustomize2.value = "rgba(0,0,0,0.4)";
	customizesalvar.value = "0";

}


function setcustomize() {
	const fs = require("fs");

	fs.readFile("./config_customize.json", function read(err, data) {
		if (err) throw err;
		var configinit = JSON.parse(data);
		configFile = "./customize/config_customize_" + configinit.config_customize + ".json"




		/* efeito */
		document.documentElement.style.setProperty("--config-efeitoinicial", document.getElementById("efeitoinicial").value);

		document.documentElement.style.setProperty("--config-quantidadebk", document.getElementById("quantidadebk").value);

		/* TAB */
		document.documentElement.style.setProperty("--config-tabbg", document.getElementById("tabbg").value);
		document.documentElement.style.setProperty("--config-tabbghover", document.getElementById("tabbghover").value);
		document.documentElement.style.setProperty("--config-tabborder", document.getElementById("tabborder").value);
		document.documentElement.style.setProperty("--config-tabbgtop", document.getElementById("tabbgtop").value);
		document.documentElement.style.setProperty("--config-tabbgtopativo", document.getElementById("tabbgtopativo").value);

		/* Corpo */
		document.documentElement.style.setProperty("--config-customizetexto", document.getElementById("customizetexto").value);
		document.documentElement.style.setProperty("--config-customizebf", document.getElementById("customizebf").value);
		document.documentElement.style.setProperty("--config-customizebb", document.getElementById("customizebb").value);
		document.documentElement.style.setProperty("--config-customizecxtxt", document.getElementById("customizecxtxt").value);
		document.documentElement.style.setProperty("--config-customizecxb", document.getElementById("customizecxb").value);
		document.documentElement.style.setProperty("--config-customizecxf", document.getElementById("customizecxf").value);
		document.documentElement.style.setProperty("--config-customizecorpo1", document.getElementById("customizecorpo1").value);
		document.documentElement.style.setProperty("--config-customizecorpo2", document.getElementById("customizecorpo2").value);
		document.documentElement.style.setProperty("--config-customizec8", document.getElementById("customizec8").value);
		document.documentElement.style.setProperty("--config-customizec9", document.getElementById("customizec9").value);
		document.documentElement.style.setProperty("--config-customizec10", document.getElementById("customizec10").value);
		document.documentElement.style.setProperty("--config-customizec11", document.getElementById("customizec11").value);
		document.documentElement.style.setProperty("--config-customizec12", document.getElementById("customizec12").value);
		document.documentElement.style.setProperty("--config-customizec13", document.getElementById("customizec13").value);

		/* Menu */
		document.documentElement.style.setProperty("--config-customizemenu1", document.getElementById("customizemenu1").value);
		document.documentElement.style.setProperty("--config-customizemenu2", document.getElementById("customizemenu2").value);
		document.documentElement.style.setProperty("--config-customizemenu3", document.getElementById("customizemenu3").value);
		document.documentElement.style.setProperty("--config-customizemenu4", document.getElementById("customizemenu4").value);
		document.documentElement.style.setProperty("--config-customizemenu5", document.getElementById("customizemenu5").value);
		document.documentElement.style.setProperty("--config-customizemenu6", document.getElementById("customizemenu6").value);
		document.documentElement.style.setProperty("--config-customizemenu7", document.getElementById("customizemenu7").value);


		/* rolagem */
		document.documentElement.style.setProperty("--config-customizerolagem1", document.getElementById("customizerolagem1").value);
		document.documentElement.style.setProperty("--config-customizerolagem2", document.getElementById("customizerolagem2").value);
		document.documentElement.style.setProperty("--config-customizerolagem3", document.getElementById("customizerolagem3").value);
		document.documentElement.style.setProperty("--config-customizerolagem4", document.getElementById("customizerolagem4").value);
		document.documentElement.style.setProperty("--config-customizerolagem5", document.getElementById("customizerolagem5").value);
		document.documentElement.style.setProperty("--config-customizerolagem6", document.getElementById("customizerolagem6").value);
		document.documentElement.style.setProperty("--config-customizerolagem7", document.getElementById("customizerolagem7").value);


		/* Actions & Eventos  */
		document.documentElement.style.setProperty("--config-customizeae1", document.getElementById("customizeae1").value);
		document.documentElement.style.setProperty("--config-customizeae2", document.getElementById("customizeae2").value);
		document.documentElement.style.setProperty("--config-customizeae3", document.getElementById("customizeae3").value);
		document.documentElement.style.setProperty("--config-customizeae4", document.getElementById("customizeae4").value);
		document.documentElement.style.setProperty("--config-customizeae5", document.getElementById("customizeae5").value);
		document.documentElement.style.setProperty("--config-customizeae6", document.getElementById("customizeae6").value);
		document.documentElement.style.setProperty("--config-customizeae7", document.getElementById("customizeae7").value);
		document.documentElement.style.setProperty("--config-customizeae8", document.getElementById("customizeae8").value);
		document.documentElement.style.setProperty("--config-customizeae9", document.getElementById("customizeae9").value);

		/* Janela de Actions  */
		document.documentElement.style.setProperty("--config-customizej1", document.getElementById("customizej1").value);
		document.documentElement.style.setProperty("--config-customizej2", document.getElementById("customizej2").value);
		document.documentElement.style.setProperty("--config-customizej3", document.getElementById("customizej3").value);
		document.documentElement.style.setProperty("--config-customizej4", document.getElementById("customizej4").value);
		document.documentElement.style.setProperty("--config-customizej5", document.getElementById("customizej5").value);
		document.documentElement.style.setProperty("--config-customizej6", document.getElementById("customizej6").value);
		document.documentElement.style.setProperty("--config-customizej7", document.getElementById("customizej7").value);
		document.documentElement.style.setProperty("--config-customizej8", document.getElementById("customizej8").value);
		document.documentElement.style.setProperty("--config-customizej9", document.getElementById("customizej9").value);
		document.documentElement.style.setProperty("--config-customizej10", document.getElementById("customizej10").value);
		document.documentElement.style.setProperty("--config-customizej11", document.getElementById("customizej11").value);
		document.documentElement.style.setProperty("--config-customizej12", document.getElementById("customizej12").value);
		document.documentElement.style.setProperty("--config-customizej13", document.getElementById("customizej13").value);

		/* Botão */
		document.documentElement.style.setProperty("--config-customizebotao", document.getElementById("customizebotao").value);
		document.documentElement.style.setProperty("--config-customizebotaotexto", document.getElementById("customizebotaotexto").value);
		document.documentElement.style.setProperty("--config-customizebotaoh", document.getElementById("customizebotaoh").value);
		document.documentElement.style.setProperty("--config-customizebotaotextoh", document.getElementById("customizebotaotextoh").value);

		/* Marcador de comandos e eventos */
		document.documentElement.style.setProperty("--config-marcador", document.getElementById("cordomarcador").value);
		document.documentElement.style.setProperty("--config-marcadortxt", document.getElementById("cordomarcadortxt").value);

		/* Notas */
		document.documentElement.style.setProperty("--config-notasfundo", document.getElementById("notasfundo").value);
		document.documentElement.style.setProperty("--config-notastxt", document.getElementById("notastxt").value);
		document.documentElement.style.setProperty("--config-bordanotas", document.getElementById("bordanotas").value);


		document.documentElement.style.setProperty("--config-fundo", document.getElementById("cordofundo").value);
		document.documentElement.style.setProperty("--config-fundo2", document.getElementById("cordofundo2").value);
		document.documentElement.style.setProperty("--config-customizesalvar", document.getElementById("customizesalvar").value);

		if (notasgat.checked == true) {
			document.querySelector("[name='notasport']").style.display = "none";
		} else {
			document.querySelector("[name='notasport']").style.display = "block";
		}

		if (filtrosgat.checked == true) {
			document.querySelector("[name='filtrosgat1']").style.display = "none";
			document.querySelector("[name='filtrosgat2']").style.display = "none";
			document.querySelector("[name='filtrosgat3']").style.display = "none";
			document.querySelector("[name='filtrosgat4']").style.display = "none";
		} else {
			document.querySelector("[name='filtrosgat1']").style.display = "block";
			document.querySelector("[name='filtrosgat2']").style.display = "block";
			document.querySelector("[name='filtrosgat3']").style.display = "block";
			document.querySelector("[name='filtrosgat4']").style.display = "block";
		}

		if (msavegat.checked == true) {
			document.querySelector("[name='msavegat1']").style.display = "none";
			document.querySelector("[name='msavegat2']").style.display = "none";
		} else {
			document.querySelector("[name='msavegat1']").style.display = "block";
			document.querySelector("[name='msavegat2']").style.display = "block";
		}

		if (custosavegat.checked == true) {
			document.querySelector("[name='custosavegat1']").style.display = "none";
		} else {
			document.querySelector("[name='custosavegat1']").style.display = "block";
		}


		fs.writeFile(configFile, JSON.stringify({ "versaocustomize": versaocustomize, "fundo": fundocustomize.value, "fundo2": fundocustomize2.value, "customizesalvar": customizesalvar.value, "marcador": marcadorcustomize.value, "marcadortxt": marcadorcustomizetxt.value, "notasfundo": notasfundo.value, "notastxt": notastxt.value, "bordanotas": bordanotas.value, "customizetexto": customizetexto.value, "customizebf": customizebf.value, "customizebb": customizebb.value, "customizecxtxt": customizecxtxt.value, "customizecxb": customizecxb.value, "customizecxf": customizecxf.value, "customizebotaotexto": customizebotaotexto.value, "customizebotao": customizebotao.value, "customizemenu1": customizemenu1.value, "customizemenu2": customizemenu2.value, "customizemenu3": customizemenu3.value, "customizemenu4": customizemenu4.value, "customizemenu5": customizemenu5.value, "customizemenu6": customizemenu6.value, "customizemenu7": customizemenu7.value, "customizeae1": customizeae1.value, "customizeae2": customizeae2.value, "customizeae3": customizeae3.value, "customizeae4": customizeae4.value, "customizeae5": customizeae5.value, "customizeae6": customizeae6.value, "customizeae7": customizeae7.value, "customizeae8": customizeae8.value, "customizeae9": customizeae9.value, "customizecorpo1": customizecorpo1.value, "customizecorpo2": customizecorpo2.value, "customizerolagem1": customizerolagem1.value, "customizerolagem2": customizerolagem2.value, "customizerolagem3": customizerolagem3.value, "customizerolagem4": customizerolagem4.value, "customizerolagem5": customizerolagem5.value, "customizerolagem6": customizerolagem6.value, "customizerolagem7": customizerolagem7.value, "customizej1": customizej1.value, "customizej2": customizej2.value, "customizej3": customizej3.value, "customizej4": customizej4.value, "customizej5": customizej5.value, "customizej6": customizej6.value, "customizej7": customizej7.value,
		"customizej8": customizej8.value, "customizej9": customizej9.value, "customizej10": customizej10.value, "customizej11": customizej11.value, "customizej12": customizej12.value, "customizej13": customizej13.value,
		"customizec8": customizec8.value, "customizec9": customizec9.value, "customizec10": customizec10.value, "customizec11": customizec11.value, "customizec12": customizec12.value, "customizec13": customizec13.value,
		"custosavegat": custosavegat.checked,
		"customizebotaotextoh": customizebotaotextoh.value, "customizebotaoh": customizebotaoh.value, "efeitoinicial": efeitoinicial.value, "tabbg": tabbg.value, "tabbghover": tabbghover.value, "tabborder": tabborder.value, "tabbgtop": tabbgtop.value, "tabbgtopativo": tabbgtopativo.value, "notasgat": notasgat.checked, "filtrosgat": filtrosgat.checked, "msavegat": msavegat.checked, "bkpsave": bkpsave.checked, "quantidadebk": quantidadebk.value }), (err) => { if (err) throw err; });
	})
} 
